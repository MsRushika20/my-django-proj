from django.urls import path
from .views import checkout, receipt

urlpatterns = [
    path('checkout/', checkout),
    path('receipt/', receipt),
]
